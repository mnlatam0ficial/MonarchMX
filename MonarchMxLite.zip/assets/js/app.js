// Configuración
const numeroWhatsApp = "522220000000"; // Sustituye por tu número

// Base de datos de productos
const productos = [
    { id: "MNK-001", marca: "Nike", nombre: "Air Max 3", precio: "$1,400" },
    { id: "MNK-002", marca: "Jordan", nombre: "6 Rings", precio: "$1,800" },
    { id: "MNK-003", marca: "Nike", nombre: "Air Max 720 Orca / Sport", precio: "$2,000" },
    { id: "MNK-004", marca: "Nike", nombre: "Air Max 97", precio: "$2,000" },
    { id: "MNK-005", marca: "New Balance", nombre: "990 Late Vino / Clásico", precio: "$1,400" },
    { id: "MNK-006", marca: "Adidas", nombre: "Adizero Ultra Ligero", precio: "$1,800" },
    { id: "MNK-007", marca: "Nike", nombre: "Air Force 1 Clásico", precio: "$1,600" },
    { id: "MNK-008", marca: "Nike", nombre: "Air Force 1 Premium Importado", precio: "$1,900" },
    { id: "MNK-009", marca: "Alexander McQueen", nombre: "Edición Pedrería / Swaro", precio: "$2,600" },
    { id: "MNK-010", marca: "Alexander McQueen", nombre: "Rotulado Clásico", precio: "$1,900" },
    { id: "MNK-011", marca: "Nike", nombre: "Blazer Mid / Doble Swoosh", precio: "$1,500" },
    { id: "MNK-012", marca: "Nike", nombre: "Air Max Plus TN Camaleón", precio: "$2,400" },
    { id: "MNK-013", marca: "Nike", nombre: "Cortez Clásico", precio: "$1,300" },
    { id: "MNK-014", marca: "Nike", nombre: "Dunk Low Piel", precio: "$1,500" },
    { id: "MNK-015", marca: "Jordan", nombre: "1 Retro Fragment", precio: "$1,500" },
    { id: "MNK-016", marca: "Golden Goose", nombre: "Golden Premium", precio: "$1,800" },
    { id: "MNK-017", marca: "Nike", nombre: "Hyperdunk", precio: "$2,400" },
    { id: "MNK-018", marca: "Nike", nombre: "LeBron", precio: "$2,300" },
    { id: "MNK-019", marca: "Adidas", nombre: "Forum Bad Bunny", precio: "$1,900" },
    { id: "MNK-020", marca: "Christian Louboutin", nombre: "Bota Suela Roja", precio: "$2,100" },
    { id: "MNK-021", marca: "Louis Vuitton", nombre: "Monogram / Clásico", precio: "$2,000" },
    { id: "MNK-022", marca: "Nike", nombre: "Metcon", precio: "$1,600" },
    { id: "MNK-023", marca: "New Balance", nombre: "530", precio: "$1,500" },
    { id: "MNK-024", marca: "New Balance", nombre: "9060", precio: "$1,800" },
    { id: "MNK-025", marca: "Nike", nombre: "Nocta", precio: "$1,700" },
    { id: "MNK-026", marca: "On", nombre: "On Cloud Clásico", precio: "$1,900" },
    { id: "MNK-027", marca: "On", nombre: "On Cloud Edición Especial", precio: "$2,100" },
    { id: "MNK-028", marca: "Nike", nombre: "Air Pippen", precio: "$2,000" },
    { id: "MNK-029", marca: "Jordan", nombre: "4 Retro", precio: "$1,600" },
    { id: "MNK-030", marca: "Adidas", nombre: "Samba Clásico / Ediciones", precio: "$1,500" },
    { id: "MNK-031", marca: "Christian Louboutin", nombre: "Low Suelita Roja", precio: "$2,100" },
    { id: "MNK-032", marca: "Adidas", nombre: "Superstar", precio: "$1,700" },
    { id: "MNK-033", marca: "Adidas", nombre: "Terrex", precio: "$1,900" },
    { id: "MNK-034", marca: "Timberland", nombre: "Clásica", precio: "$1,600" },
    { id: "MNK-035", marca: "Nike", nombre: "Travis Scott", precio: "$1,500" },
    { id: "MNK-036", marca: "Adidas", nombre: "Ultraboost", precio: "$2,000" },
    { id: "MNK-037", marca: "Vans", nombre: "Old Skool / Suede", precio: "$1,400" }
];

// Elementos del DOM
const grid = document.getElementById('catalogGrid');
const searchInput = document.getElementById('searchInput');
const brandFilter = document.getElementById('brandFilter');
const priceSort = document.getElementById('priceSort');

// Utilidad: Parsear precio a número
function parsePrice(priceString) {
    return parseInt(priceString.replace(/[^0-9]/g, ''));
}

// Renderizar tarjetas
function renderProducts(items) {
    grid.innerHTML = '';
    
    if(items.length === 0) {
        grid.innerHTML = '<div class="no-results">No se encontraron modelos con estos filtros.</div>';
        return;
    }

    items.forEach(item => {
        const mensaje = encodeURIComponent(`Hola Monarch Mx, busco el modelo ${item.marca} ${item.nombre} (ID: ${item.id}). ¿Tienen disponibilidad?`);
        const enlaceWA = `https://wa.me/${numeroWhatsApp}?text=${mensaje}`;

        // Nota: Cuando tengas las fotos, cambia el div .image-placeholder por algo como:
        // <img src="assets/images/${item.id}.jpg" class="image-placeholder" alt="${item.nombre}">
        
        const cardHTML = `
            <div class="card">
                <div class="image-placeholder">IMG // ${item.id}</div>
                <div class="info">
                    <div class="brand">${item.marca}</div>
                    <div class="name">${item.nombre}</div>
                    <div class="id-tag">REF: ${item.id}</div>
                    <div class="price">${item.precio}</div>
                    <a href="${enlaceWA}" target="_blank" class="btn-buy">Solicitar Pieza</a>
                </div>
            </div>
        `;
        grid.innerHTML += cardHTML;
    });
}

// Motor de Filtros
function updateCatalog() {
    const query = searchInput.value.toLowerCase();
    const brand = brandFilter.value;
    const sortMethod = priceSort.value;

    let filteredItems = productos.filter(p => {
        const matchText = p.nombre.toLowerCase().includes(query) || 
                          p.marca.toLowerCase().includes(query) || 
                          p.id.toLowerCase().includes(query);
        const matchBrand = brand === 'all' || p.marca === brand;
        return matchText && matchBrand;
    });

    if (sortMethod === 'asc') {
        filteredItems.sort((a, b) => parsePrice(a.precio) - parsePrice(b.precio));
    } else if (sortMethod === 'desc') {
        filteredItems.sort((a, b) => parsePrice(b.precio) - parsePrice(a.precio));
    }

    renderProducts(filteredItems);
}

// Event Listeners
searchInput.addEventListener('input', updateCatalog);
brandFilter.addEventListener('change', updateCatalog);
priceSort.addEventListener('change', updateCatalog);

// Init
document.addEventListener('DOMContentLoaded', () => {
    renderProducts(productos);
});
